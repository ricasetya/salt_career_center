// ignore_for_file: public_member_api_docs, sort_constructors_first
class AddresDetailResponse {
  String? address;
  String? kelurahan;
  String? kecamatan;
  String? city;
  String? province;
  AddresDetailResponse({
    this.address,
    this.kelurahan,
    this.kecamatan,
    this.city,
    this.province,
  });
}
