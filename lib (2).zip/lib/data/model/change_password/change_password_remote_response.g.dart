// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'change_password_remote_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ChangePasswordRemoteResponse _$ChangePasswordRemoteResponseFromJson(
        Map<String, dynamic> json) =>
    ChangePasswordRemoteResponse(
      id: json['id'] as String?,
    );

Map<String, dynamic> _$ChangePasswordRemoteResponseToJson(
        ChangePasswordRemoteResponse instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
