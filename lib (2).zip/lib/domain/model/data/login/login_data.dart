class LoginData {
  String token;

  LoginData(this.token);
}
