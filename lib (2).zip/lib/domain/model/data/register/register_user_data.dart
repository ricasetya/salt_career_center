// ignore_for_file: public_member_api_docs, sort_constructors_first
class UserRegisterData {
  String? username;
  String? nama;
  String? password;
  UserRegisterData({
    this.username,
    this.nama,
    this.password,
  });
}
