// ignore_for_file: public_member_api_docs, sort_constructors_first
class JobsCompanyData {
  String? skill;
  String? nameCompany;
  String? addres;
  String? createdAt;
  JobsCompanyData({
    this.skill,
    this.nameCompany,
    this.addres,
    this.createdAt,
  });
}
