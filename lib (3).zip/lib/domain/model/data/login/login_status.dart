class LoginStatus {
  int code;
  String message;
  LoginStatus(
    this.code,
    this.message,
  );
}
