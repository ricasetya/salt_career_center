// ignore_for_file: public_member_api_docs, sort_constructors_first
class ListsCompanyData {
  String? name;
  String? typeCompany;
  String? address;
  String? logo;
  String? id;
  ListsCompanyData({
    this.name,
    this.typeCompany,
    this.address,
    this.logo,
    this.id,
  });
}
