// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'article_source_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ArticleSourceResponse _$ArticleSourceResponseFromJson(
        Map<String, dynamic> json) =>
    ArticleSourceResponse(
      id: json['id'] as String?,
      name: json['name'] as String?,
    );

Map<String, dynamic> _$ArticleSourceResponseToJson(
        ArticleSourceResponse instance) =>
    <String, dynamic>{
      'id': instance.id,
      'name': instance.name,
    };
