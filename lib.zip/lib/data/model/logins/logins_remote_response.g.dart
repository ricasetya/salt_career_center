// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'logins_remote_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LoginsRemoteResponse _$LoginsRemoteResponseFromJson(
        Map<String, dynamic> json) =>
    LoginsRemoteResponse(
      token: json['token'] as String?,
    );

Map<String, dynamic> _$LoginsRemoteResponseToJson(
        LoginsRemoteResponse instance) =>
    <String, dynamic>{
      'token': instance.token,
    };
