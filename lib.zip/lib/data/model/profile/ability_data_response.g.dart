// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ability_data_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AbilityDataResponse _$AbilityDataResponseFromJson(Map<String, dynamic> json) =>
    AbilityDataResponse(
      ability: json['ability'] as String?,
    );

Map<String, dynamic> _$AbilityDataResponseToJson(
        AbilityDataResponse instance) =>
    <String, dynamic>{
      'ability': instance.ability,
    };
