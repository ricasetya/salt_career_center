// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'language_data_reponse.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LanguageDataResponse _$LanguageDataResponseFromJson(
        Map<String, dynamic> json) =>
    LanguageDataResponse(
      language: json['language'] as String?,
    );

Map<String, dynamic> _$LanguageDataResponseToJson(
        LanguageDataResponse instance) =>
    <String, dynamic>{
      'language': instance.language,
    };
