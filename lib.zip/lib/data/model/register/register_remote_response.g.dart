// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_remote_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegisterRemoteResponse _$RegisterRemoteResponseFromJson(
        Map<String, dynamic> json) =>
    RegisterRemoteResponse(
      id: json['id'] as int?,
    );

Map<String, dynamic> _$RegisterRemoteResponseToJson(
        RegisterRemoteResponse instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
