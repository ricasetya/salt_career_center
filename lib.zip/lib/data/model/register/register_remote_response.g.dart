// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'register_remote_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegisterRemoteResponse _$RegisterRemoteResponseFromJson(
        Map<String, dynamic> json) =>
    RegisterRemoteResponse(
      username: json['username'] as String?,
      nama: json['nama'] as String?,
      password: json['password'] as String?,
    );

Map<String, dynamic> _$RegisterRemoteResponseToJson(
        RegisterRemoteResponse instance) =>
    <String, dynamic>{
      'username': instance.username,
      'nama': instance.nama,
      'password': instance.password,
    };
