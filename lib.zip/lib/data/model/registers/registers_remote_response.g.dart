// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'registers_remote_response.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RegistersRemoteResponse _$RegistersRemoteResponseFromJson(
        Map<String, dynamic> json) =>
    RegistersRemoteResponse(
      id: json['id'] as int?,
    );

Map<String, dynamic> _$RegistersRemoteResponseToJson(
        RegistersRemoteResponse instance) =>
    <String, dynamic>{
      'id': instance.id,
    };
