class ArticleSourceData {
  String id;
  String name;

  ArticleSourceData(this.id, this.name);
}
