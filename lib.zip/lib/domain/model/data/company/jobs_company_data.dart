// ignore_for_file: public_member_api_docs, sort_constructors_first
class JobsCompanyData {
  String? skill;
  String? nameCompany;
  String? address;
  String? createdAt;
  JobsCompanyData({
    this.skill,
    this.nameCompany,
    this.address,
    this.createdAt,
  });
}
