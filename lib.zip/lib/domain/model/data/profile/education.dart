class UpdateEducation {
  String id;
  String profileId;
  UpdateEducation(this.id, this.profileId);
}
