// ignore_for_file: public_member_api_docs, sort_constructors_first
class EducationData {
  String? name;
  String? startEducation;
  String? endEducation;
  String? skillExperience;
  String? description;
  EducationData({
    this.name,
    this.startEducation,
    this.endEducation,
    this.skillExperience,
    this.description,
  });
}
