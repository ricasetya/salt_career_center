// ignore_for_file: public_member_api_docs, sort_constructors_first
class WorkExperienceData {
  String? skillExperience;
  String? name;
  String? startWork;
  String? endWork;
  String? description;
  WorkExperienceData({
    this.skillExperience,
    this.name,
    this.startWork,
    this.endWork,
    this.description,
  });
}
