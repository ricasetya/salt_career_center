class UserRegisterData {
  int? id;
  UserRegisterData({
    this.id,
  });
}
