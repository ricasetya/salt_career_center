class Routes {
//login
  //static var login = "login";
  static var loginmocPage = "loginmoc";

//register
  static var registersPage = "registers";
  static var registerPage = "register";

//resetpasword
  static var forgotpasswordsPage = "forgotpassword";
  static var forgotpassworemailsentdPage = "forgotpassworemailsent";
  static var forgotpasswordupdatepasswordPage = "forgotpasswordupdatepassword";
  static var forgotpasswordupdatepasswordsuccesPage =
      "forgotpasswordupdatepasswordsucces";

//home
  static var homescreenPage = "homescreen";

//pekerjaan
  static var jobscreenPage = "jobscreen";

//company
  static var companyscreenPage = "companyscreen";
  static var postcompanyPage = "postcompany";

// Notifikasi
  static var notifikasiPage = "notifikasi";

// Profile
  static var profileblankPage = "profileblank";
  static var profilesettingsPage = "profilesettings";
  static var profileupdatepasswordPage = "profileupdatepassword";
  static var profileeditprofilePage = "profileeditprofile";
  static var profileinputabilityPage = "profileinputability";
  static var profileinputlanguagePage = "profileinputlanguage";
  static var workexperience = "experince";

  // akbar
  static var profileinputportofolioPage = "profileinputportofolio";

// Search
  static var searchscreenPage = "searchscreen";
}
