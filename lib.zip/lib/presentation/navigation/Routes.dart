class Routes {
//login
  static var login = "login";
  static var loginsPage = "logins";
  static var loginmocPage = "loginmoc";

//register
  static var registerPage = "register";
  static var registersPage = "registers";

//resetpasword
  static var forgotpasswordsPage = "forgotpassword";
  static var forgotpassworemailsentdPage = "forgotpassworemailsent";
  static var forgotpasswordupdatepasswordPage = "forgotpasswordupdatepassword";
  static var forgotpasswordupdatepasswordsuccesPage =
      "forgotpasswordupdatepasswordsucces";

//beranda
  static var berandaPage = "beranda";

//pekerjaan
  static var dafpek2Page = "dafpek2";
  static var sudahmelamarPage = "sudahmelamar";
  static var listsjobsPage = "listsjobs";
  static var detailPage = "detailpage";

//company
  static var companyscreenPage = "companyscreen";
  static var postcompanyPage = "postcompany";

// Notifikasi
  static var notifikasiPage = "notifikasi";

// Profile
  static var profileblankPage = "profileblank";
  static var profilesettingsPage = "profilesettings";
  static var profileupdatepasswordPage = "profileupdatepassword";
  static var profileeditprofilePage = "profileeditprofile";
  static var profileinputabilityPage = "profileinputability";
  static var profileinputlanguagePage = "profileinputlanguage";
  // akbar
  static var profileinputportofolioPage = "profileinputportofolio";

// Search
  static var searchorangPage = "searchorang";

// Sample
  static var backendPage = "backend";
  static var articlescreenPage = "articlescreen";
  static var samplecobaPage = "samplecoba";
}
